var translations = {
    "Bem-vindo ao nosso site!": "Welcome to our website!",
    "Fale conosco.": "Contact us.",
    // Adicione mais traduções aqui
};