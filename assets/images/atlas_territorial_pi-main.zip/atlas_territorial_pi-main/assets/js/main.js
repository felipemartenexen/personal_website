var sidebar = L.control.sidebar('sidebar_dados', {
    closeButton: true,
    position: 'right'
});

map.addControl(sidebar);

function highlight(layer) {
    layer.setStyle({
        weight: 3,
        dashArray: '',
        color: 'red'
    });
    if (!L.Browser.ie && !L.Browser.opera) {
        layer.bringToFront();
    }
}

function dehighlight(layer) {
    if (selected === null || selected._leaflet_id !== layer._leaflet_id) {
        atlas.resetStyle(layer);
    }
}

function select(layer) {
    if (selected !== null) {
        var previous = selected;
    }
    map.fitBounds(layer.getBounds());
    selected = layer;
    if (previous) {
        dehighlight(previous);
    }
}

var selected = null;

var atlas = L.geoJSON(atlas_2, {
        style: {
            color: "black",
            fillOpacity: 0,
            weight: 0,
        },
        onEachFeature: function(feature, layer) {
            layer.on({
                'mouseover': function(e) {
                    highlight(e.target);
                },
                'mouseout': function(e) {
                    dehighlight(e.target);
                },
                'click': function(e) {
                    select(e.target);
                }
            });
            const p = layer.feature.properties;
            p.search = p.NM_MUN;
            layer.on('click', function(e) {

                $('#municipio').html(e.target.feature.properties.NM_MUN)

                document.getElementById("area_municipio").innerHTML = e.target.feature.properties.area_ibge.toLocaleString()

                var ctx = document.getElementById('canvas').getContext('2d');


                var color = Chart.helpers.color;


                var area_ibge = e.target.feature.properties.area_ibge * 1
                var area_sncr = e.target.feature.properties.area_total * 1
                var area_censo = e.target.feature.properties.area_est_a * 1
                var area_sicar = e.target.feature.properties.area_tot_6 * 1
                var area_assentamento = e.target.feature.properties.assent_ha * 1
                var area_quilombola = e.target.feature.properties.quilomb_ha * 1
                var area_sigef = (e.target.feature.properties.sigefPr_ha + e.target.feature.properties.sigefPu_ha) * 1
                var area_uc = e.target.feature.properties.unidCon_ha * 1
                var area_noGeo = e.target.feature.properties.noInfor_ha * 1


                var qtd_sncr = e.target.feature.properties.total_im_2
                var qtd_censo = e.target.feature.properties.est_agro_2
                var qtd_sicar = e.target.feature.properties.num_de_c_1

                var class_prop_0_4 = e.target.feature.properties.class_prop
                var class_prop_4_15 = e.target.feature.properties.class_pr_1
                var class_prop_15 = e.target.feature.properties.class_pr_2
                var class_posse_0_4 = e.target.feature.properties.class_poss
                var class_posse_4_15 = e.target.feature.properties.class_po_1
                var class_posse_15 = e.target.feature.properties.class_po_2

                var area_prop_0_4 = e.target.feature.properties.area_class * 1
                var area_prop_4_15 = e.target.feature.properties.area_cla_1 * 1
                var area_prop_15 = e.target.feature.properties.area_cla_2 * 1
                var area_posse_0_4 = e.target.feature.properties.area_cla_3 * 1
                var area_posse_4_15 = e.target.feature.properties.area_cla_4 * 1
                var area_posse_15 = e.target.feature.properties.area_cla_5 * 1


                var prop_porc = e.target.feature.properties.prop_porc
                var posse_porc = e.target.feature.properties.poss_porc

                var floresta_1985 = e.target.feature.properties.uso_1_85 * 1
                var floresta_1990 = e.target.feature.properties.uso_1_90 * 1
                var floresta_1995 = e.target.feature.properties.uso_1_95 * 1
                var floresta_2000 = e.target.feature.properties.uso_1_00 * 1
                var floresta_2005 = e.target.feature.properties.uso_1_05 * 1
                var floresta_2010 = e.target.feature.properties.uso_1_10 * 1
                var floresta_2015 = e.target.feature.properties.uso_1_15 * 1
                var floresta_2019 = e.target.feature.properties.uso_1_19 * 1

                var no_floresta_1985 = e.target.feature.properties.uso_2_85 * 1
                var no_floresta_1990 = e.target.feature.properties.uso_2_90 * 1
                var no_floresta_1995 = e.target.feature.properties.uso_2_95 * 1
                var no_floresta_2000 = parseInt(e.target.feature.properties.uso_2_00) * 1
                var no_floresta_2005 = e.target.feature.properties.uso_2_05 * 1
                var no_floresta_2010 = e.target.feature.properties.uso_2_10 * 1
                var no_floresta_2015 = e.target.feature.properties.uso_2_15 * 1
                var no_floresta_2019 = e.target.feature.properties.uso_2_19 * 1

                var agro_1985 = e.target.feature.properties.uso_3_85 * 1
                var agro_1990 = e.target.feature.properties.uso_3_90 * 1
                var agro_1995 = e.target.feature.properties.uso_3_95 * 1
                var agro_2000 = e.target.feature.properties.uso_3_00 * 1
                var agro_2005 = e.target.feature.properties.uso_3_05 * 1
                var agro_2010 = e.target.feature.properties.uso_3_10 * 1
                var agro_2015 = e.target.feature.properties.uso_3_15 * 1
                var agro_2019 = e.target.feature.properties.uso_3_19 * 1

                var no_vegetada_1985 = e.target.feature.properties.uso_4_85 * 1
                var no_vegetada_1990 = e.target.feature.properties.uso_4_90 * 1
                var no_vegetada_1995 = e.target.feature.properties.uso_4_95 * 1
                var no_vegetada_2000 = e.target.feature.properties.uso_4_00 * 1
                var no_vegetada_2005 = e.target.feature.properties.uso_4_05 * 1
                var no_vegetada_2010 = e.target.feature.properties.uso_4_10 * 1
                var no_vegetada_2015 = e.target.feature.properties.uso_4_15 * 1
                var no_vegetada_2019 = e.target.feature.properties.uso_4_19 * 1

                var hidro_1985 = e.target.feature.properties.uso_5_85 * 1
                var hidro_1990 = e.target.feature.properties.uso_5_90 * 1
                var hidro_1995 = e.target.feature.properties.uso_5_95 * 1
                var hidro_2000 = e.target.feature.properties.uso_5_00 * 1
                var hidro_2005 = e.target.feature.properties.uso_5_05 * 1
                var hidro_2010 = e.target.feature.properties.uso_5_10 * 1
                var hidro_2015 = e.target.feature.properties.uso_5_15 * 1
                var hidro_2019 = e.target.feature.properties.uso_5_19 * 1


                //Gráfico Áreas Cadastradas
                var config = {
                    type: 'bar',
                    data: {
                        labels: ['Área em ha'],
                        datasets: [{
                                label: 'IBGE',
                                backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.red,
                                borderWidth: 1,
                                data: [area_ibge],
                            },
                            {
                                label: 'SNCR',
                                backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.blue,
                                borderWidth: 1,
                                data: [area_sncr],
                            },
                            {
                                label: 'Censo Agropecuário',
                                backgroundColor: color(window.chartColors.yellow).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.yellow,
                                borderWidth: 1,
                                data: [area_censo],
                            },
                            {
                                label: 'SICAR',
                                backgroundColor: color(window.chartColors.orange).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.orange,
                                borderWidth: 1,
                                data: [area_sicar],
                            },
                            {
                                label: 'Assentamento',
                                backgroundColor: color(window.chartColors.marrom).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.marrom,
                                borderWidth: 1,
                                data: [area_assentamento],
                            },
                            {
                                label: 'Quilombola',
                                backgroundColor: color(window.chartColors.grey).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.grey,
                                borderWidth: 1,
                                data: [area_quilombola],
                            },
                            {
                                label: 'SIGEF',
                                backgroundColor: color(window.chartColors.pink).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.pink,
                                borderWidth: 1,
                                data: [area_sigef],
                            },
                            {
                                label: 'Unidade Conservação',
                                backgroundColor: color(window.chartColors.green).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.green,
                                borderWidth: 1,
                                data: [area_uc],
                            },
                            {
                                label: 'Não Geoespacializada',
                                backgroundColor: color(window.chartColors.purple).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.purple,
                                borderWidth: 1,
                                data: [area_noGeo],
                            },

                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Áreas Cadastradas'
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                    callback: function(value, index, values) {
                                        if (parseInt(value) >= 1000) {
                                            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                        } else {
                                            return value;
                                        }
                                    }
                                }
                            }]
                        }
                    }
                };
                if (window.bar_1 != undefined)
                    window.bar_1.destroy();
                window.bar_1 = new Chart(ctx, config);
                // Fim Gráfico Áreas Cadastradas


                //Gráfico Radar
                var ctx_radarGrafico = document.getElementById('radarGrafico').getContext('2d');


                var config_radar = {
                    type: 'radar',
                    data: {
                        labels: ['Propriedade - 0 a 4 MF', 'Propriedade - 4 a 15 MF', 'Propriedade - Acima 15 MF', 'Posse - 0 a 4 MF', 'Posse - 4 a 15 MF', 'Posse - Acima de 15 MF'],
                        datasets: [{
                                label: 'Quantidade de Imóveis',
                                backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.red,
                                borderWidth: 1,
                                data: [class_prop_0_4, class_prop_4_15, class_prop_15, class_posse_0_4, class_posse_4_15, class_posse_15],
                            },
                            {
                                label: 'Áreas dos Imóveis',
                                backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.blue,
                                borderWidth: 1,
                                data: [area_prop_0_4, area_prop_4_15, area_prop_15, area_posse_0_4, area_posse_4_15, area_posse_15],
                            },
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Imóveis Cadastrados - SNCR'
                        },
                    }
                };
                if (window.bar2 != undefined)
                    window.bar2.destroy();
                window.bar2 = new Chart(ctx_radarGrafico, config_radar);
                //Fim Gráfico Radar

                //Pie Gráfico
                var ctx_pieGrafico = document.getElementById('pieGrafico').getContext('2d');


                var config_pie = {
                    type: 'pie',
                    data: {
                        labels: ['Propriedade', 'Posse'],
                        datasets: [{
                                label: 'Quantidade de Imóveis',
                                backgroundColor: [color(window.chartColors.red).alpha(0.5).rgbString(), color(window.chartColors.blue).alpha(0.5).rgbString()],
                                borderColor: [window.chartColors.red, window.chartColors.blue],
                                borderWidth: 1,
                                data: [prop_porc, posse_porc],
                            },

                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Distribuição por Categoria - SNCR'
                        }
                    }
                };
                if (window.bar3 != undefined)
                    window.bar3.destroy();
                window.bar3 = new Chart(ctx_pieGrafico, config_pie);
                //Fim Pie Gráfico

                var ctx_qtdGrafico = document.getElementById('qtdGrafico').getContext('2d');

                var qtd_config = {
                    type: 'bar',
                    data: {
                        labels: ['Quantidade de Imóveis'],
                        datasets: [{
                                label: 'SNCR',
                                backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.blue,
                                borderWidth: 1,
                                data: [qtd_sncr],
                            },
                            {
                                label: 'Censo Agropecuário',
                                backgroundColor: color(window.chartColors.yellow).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.yellow,
                                borderWidth: 1,
                                data: [qtd_censo],
                            },
                            {
                                label: 'SICAR',
                                backgroundColor: color(window.chartColors.orange).alpha(0.5).rgbString(),
                                borderColor: window.chartColors.orange,
                                borderWidth: 1,
                                data: [qtd_sicar],
                            },

                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Imóveis Cadastrados'
                        },
                        scales: {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true
                                }
                            }],
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                    callback: function(value, index, values) {
                                        if (parseInt(value) >= 1000) {
                                            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                        } else {
                                            return value;
                                        }
                                    }
                                }
                            }]
                        }
                    }
                };
                if (window.bar_4 != undefined)
                    window.bar_4.destroy();
                window.bar_4 = new Chart(ctx_qtdGrafico, qtd_config);

                ///

                var ctx_usoGrafico = document.getElementById('usoGrafico').getContext('2d');

                var ano = ['1985', '1990', '1995', '2000', '2005', '2010', '2015', '2019'];

                var uso_config = {
                    type: 'line',
                    data: {
                        labels: ['1985', '1990', '1995', '2000', '2005', '2010', '2015', '2019'],
                        datasets: [{
                                label: 'Floresta',
                                backgroundColor: window.chartColors.green,
                                borderColor: window.chartColors.green,
                                data: [
                                    floresta_1985,
                                    floresta_1990,
                                    floresta_1995,
                                    floresta_2000,
                                    floresta_2005,
                                    floresta_2010,
                                    floresta_2015,
                                    floresta_2019,
                                ],
                                fill: false,
                            }, {
                                label: 'Não Floresta',
                                fill: false,
                                backgroundColor: window.chartColors.orange,
                                borderColor: window.chartColors.orange,
                                data: [
                                    no_floresta_1985,
                                    no_floresta_1990,
                                    no_floresta_1995,
                                    no_floresta_2000,
                                    no_floresta_2005,
                                    no_floresta_2010,
                                    no_floresta_2015,
                                    no_floresta_2019,
                                ],
                            },
                            {
                                label: 'Agricultura',
                                fill: false,
                                backgroundColor: window.chartColors.yellow,
                                borderColor: window.chartColors.yellow,
                                data: [
                                    agro_1985,
                                    agro_1990,
                                    agro_1995,
                                    agro_2000,
                                    agro_2005,
                                    agro_2010,
                                    agro_2015,
                                    agro_2019,
                                ],
                            },
                            {
                                label: 'Não Vegetada',
                                fill: false,
                                backgroundColor: window.chartColors.red,
                                borderColor: window.chartColors.red,
                                data: [
                                    no_vegetada_1985,
                                    no_vegetada_1990,
                                    no_vegetada_1995,
                                    no_vegetada_2000,
                                    no_vegetada_2005,
                                    no_vegetada_2010,
                                    no_vegetada_2015,
                                    no_vegetada_2019,
                                ],
                            },
                            {
                                label: "Corpos D'água",
                                fill: false,
                                backgroundColor: window.chartColors.blue,
                                borderColor: window.chartColors.blue,
                                data: [
                                    hidro_1985,
                                    hidro_1990,
                                    hidro_1995,
                                    hidro_2000,
                                    hidro_2005,
                                    hidro_2010,
                                    hidro_2015,
                                    hidro_2019,
                                ],
                            },
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        title: {
                            display: true,
                            text: 'Uso e Cobertura do Solo'
                        },
                        tooltips: {
                            mode: 'index',
                            intersect: false,
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Ano',
                                }
                            }],
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true,
                                    callback: function(value, index, values) {
                                        if (parseInt(value) >= 1000) {
                                            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                        } else {
                                            return value;
                                        }
                                    }
                                }
                            }]
                        }
                    }
                };

                if (window.bar_5 != undefined)
                    window.bar_5.destroy();
                window.bar_5 = new Chart(ctx_usoGrafico, uso_config);
                /// Fim Gráfico de Uso do Solo

                //Pie Gráfico
                var ctx_usoAtualGrafico = document.getElementById('usoAtualGrafico').getContext('2d');


                var config_usoAtual = {
                    type: 'pie',
                    data: {
                        labels: ['Floresta', 'Agricultura', 'Não Floresta', 'Não Vegetada', "Corpos D'água"],
                        datasets: [{
                                label: 'Quantidade de Imóveis',
                                backgroundColor: [
                                    color(window.chartColors.green).alpha(0.5).rgbString(),
                                    color(window.chartColors.yellow).alpha(0.5).rgbString(),
                                    color(window.chartColors.orange).alpha(0.5).rgbString(),
                                    color(window.chartColors.red).alpha(0.5).rgbString(),
                                    color(window.chartColors.blue).alpha(0.5).rgbString(),
                                ],
                                borderColor: [
                                    window.chartColors.green,
                                    window.chartColors.yellow,
                                    window.chartColors.orange,
                                    window.chartColors.red,
                                    window.chartColors.blue,
                                ],
                                borderWidth: 1,
                                data: [floresta_2019, agro_2019, no_floresta_2019, no_vegetada_2019, hidro_2019],
                            },

                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Uso Do Solo - 2019'
                        },
                    }
                };
                if (window.bar6 != undefined)
                    window.bar6.destroy();
                window.bar6 = new Chart(ctx_usoAtualGrafico, config_usoAtual);
                //Fim Pie Gráfico


            })
        },
    }

).addTo(map).on('click', function() {
    sidebar.show();
});

setTimeout(function() {
    sidebar.show();
}, 500);


sidebar.on('show', function() {
    console.log('Sidebar will be visible.');
});

sidebar.on('shown', function() {
    console.log('Sidebar is visible.');
});


L.DomEvent.on(sidebar.getCloseButton(), 'click', function() {
    console.log('Close button clicked.');
});


function fechar() {
    sidebar.hide();
};


/*
controlSearch.on('search:locationfound', function(e) {
		
    //console.log('search:locationfound', );

    //map.removeLayer(this._markerSearch)

    e.layer.setStyle({fillColor: '#3f0', color: '#0f0'});
    if(e.layer._popup)
        e.layer.openPopup();

}).on('search:collapsed', function(e) {

    atlas.eachLayer(function(layer) {	//restore feature color
        atlas.resetStyle(layer);
    });	
});


map.addControl( controlSearch );
*/